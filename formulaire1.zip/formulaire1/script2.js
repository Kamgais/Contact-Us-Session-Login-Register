document.getElementById("username2").innerHTML += localStorage.getItem("username");
document.getElementById("pseudo2").innerHTML += localStorage.getItem("pseudo");
document.getElementById("email2").innerHTML += localStorage.getItem("email");

