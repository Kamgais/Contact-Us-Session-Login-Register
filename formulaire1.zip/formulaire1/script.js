var form = document.getElementById("form").addEventListener("submit", function autrepage(){

localStorage.setItem("username",document.getElementById("username").value) ;
localStorage.setItem("pseudo",document.getElementById("pseudo").value) ;
localStorage.setItem("email",document.getElementById("email").value) ;






})